 
//add code here to handle camera